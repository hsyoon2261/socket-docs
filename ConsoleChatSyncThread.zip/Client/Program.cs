﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace Client
{
    class ServerHandler
    {
        private StreamReader reader = null;

        public ServerHandler(StreamReader reader)
        {
            this.reader = reader;
        }
        public void Chat()
        {
            try
            {
                while (true)
                {
                    string str = reader.ReadLine();
                    Console.WriteLine(str);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            TcpClient client = null;
            try
            {
                client = new TcpClient();
                IPAddress ipAd = IPAddress.Parse("124.53.127.89");
                //IPAddress ipAd = IPAddress.Parse("192.168.112.1");

                client.Connect(ipAd,8888);

                NetworkStream stream = client.GetStream();
                StreamReader reader = new StreamReader(stream);
                StreamWriter writer = new StreamWriter(stream){AutoFlush = true};
                
                //thread
                ServerHandler serverHandler = new ServerHandler(reader);
                Thread t = new Thread(new ThreadStart(serverHandler.Chat));
                t.Start();

                string sendData = Console.ReadLine();
                while (true)
                {
                    writer.WriteLine(sendData);
                    if (sendData.IndexOf("<EOF>") > -1) 
                        break;
                    sendData = Console.ReadLine();


                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            finally
            {
                client.Close();
                client = null;
            }
        }
    }
}